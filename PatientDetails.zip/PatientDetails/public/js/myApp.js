$(document).ready(function(){
	
	$('#division').on('change',function(){
		var division_id = $(this).val();
		console.log(this.options[this.selectedIndex].text);
		$.ajax({
			method: 'GET',
			url: 'get_districts',
			data: {division_id:division_id},
			dataType: 'html',
			success:function(data){
				$('#district').html(data);
			}
		});
	});
	$('#district').on('change',function(){
		var district_id = $(this).val();
		console.log(this.options[this.selectedIndex].text);
		$.ajax({
			method: 'GET',
			url: 'get_thanas',
			data: {district_id:district_id},
			dataType: 'html',
			success:function(data){
				$('#thana').html(data);
			}
		});
	});
	$('#thana').on('change',function(){
		console.log(this.options[this.selectedIndex].text);
	});
	$("#submit").on('click',function(){
		var location = $('#thana')[0].options[$('#thana')[0].selectedIndex].text;
		location = location+" , "+ $('#division')[0].options[$('#division')[0].selectedIndex].text;
		location = location+" , "+ $('#district')[0].options[$('#district')[0].selectedIndex].text;
		console.log(location);
		$('#thana')[0].remove();
		$('#division')[0].remove();
		$('#district')[0].remove();
		var inputLocation = '<input hidden type="text" name="location" value="'+location+'">';
		console.log(inputLocation);
		$("form").append(inputLocation);
	});
	
});