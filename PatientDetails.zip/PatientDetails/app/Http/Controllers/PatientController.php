<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;

class PatientController extends Controller
{
    public function index(){
    	$patients = DB::table('patients')->get();
    	$divisions =DB::table('divisions')->get();
    	return view('welcome',compact('patients','divisions'));
    }

    public function addPatient(Request $request){
    	$data = array();
    	$data['name']=$request->name;
    	$data['dob']=$request->dob;
    	$data['cell']=$request->cell;
    	$data['disease']=$request->disease;
    	$data['location']=$request->location;
    	DB::table('patients')->insert($data);
    	return redirect()->route('index');
    }
    public function find_districts(){
    	if(isset($_GET['division_id'])){
    		$id = $_GET['division_id'];
    		$districts =DB::table('districts')->where('division_id',$id)->get();
    		echo '<option>Select District</option>';
    		foreach ($districts as $district)
    		{
    		    echo '<option value="'.$district->id.'">'.$district->name.'</option>';
    		}
    	}
    }
    public function find_thanas(){
    	if(isset($_GET['district_id'])){
    		$id = $_GET['district_id'];
    		$thanas =DB::table('thanas')->where('district_id',$id)->get();
    		echo '<option>Select thana</option>';
    		foreach ($thanas as $thana)
    		{
    		    echo '<option value="'.$thana->id.'">'.$thana->name.'</option>';
    		}
    	}
    }
}
