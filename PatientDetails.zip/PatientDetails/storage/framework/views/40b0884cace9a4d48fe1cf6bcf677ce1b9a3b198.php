<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="<?php echo e(asset('js/myApp.js')); ?>" type="text/javascript"></script>

        <!-- Styles -->
       
    </head>
    <body>
        
           

<div class="container">
    <div class="card">
  <div class="card-header text-center">
    <h5 class="card-title">All Patients</h5>
  </div>
  <div class="card-body">
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal"><span><i class="fa fa-plus"></i></span> Add Patient</button><hr>


    <div class="modal fade" id="myModal">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
          
            <!-- Modal Header -->
            <div class="modal-header">
              <h4 class="modal-title">Create New Patient</h4>
              <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
            <div class="modal-body">
              <form method="post" action="<?php echo e(Route('add.patient')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Name : </label>
                    <input required type="text" class="form-control" id="name" placeholder="Enter Name" name="name">
                </div>

                <div class="form-group">
                    <label for="dob">Date of birth : </label>
                    <input required type="date" class="form-control" id="dob" name="dob">
                </div>

                <div class="form-group">
                    <label for="cell">Cell : </label>
                    <input required type="tel" class="form-control" id="cell" placeholder="Enter cell" name="cell">
                </div>

                <div class="form-group">
                    <label for="disease">Disease : </label>
                    <textarea required class="form-control" name="disease"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="division">Division : </label>
                    <select required name="division" id="division" class="form-control">
                        <option>Select Division</option>
                        <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($division->id); ?>"><?php echo e($division->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="district">District : </label>
                    <select required name="district" id="district" class="form-control">
                        <!-- <option>Select District</option> -->
                    </select>
                </div>
                <div class="form-group">
                    <label for="thana">Thana : </label>
                    <select required name="thana" id="thana" class="form-control">
                        <!-- <option>Select Thana</option> -->
                    </select>
                </div>
                <input id="submit" type="submit" name="submit" class="btn btn-success" value="Add Patient">

              </form>
            </div>
        </div>
        </div>
  </div>




    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th>Name</th>
                <th>Disease</th>
                <th>Cell</th>
                <th>Date of birth</th>
                <th>Locations</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($patient->name); ?></td>
                <td><?php echo e($patient->disease); ?></td>
                <td><?php echo e($patient->cell); ?></td>
                <td><?php echo e($patient->dob); ?></td>
                <td><?php echo e($patient->location); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    
  </div>
</div>
</div>

        
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\PatientDetails\resources\views/welcome.blade.php ENDPATH**/ ?>